BASE PARA EL BUSCAMINAS: (Nombre alumno)
=========================

En este programa se encuentra la base para el Buscaminas de Desarrollo de intefaces (DAM2).

Pasos
-----

1. Descárgate el cliente de github si no lo tienes en tu equipo. Créate una cuenta y loguéate.

2. Haz un fork de este repositorio. Un Fork se utiliza para modificar el trabajo de otras personas sin que trabajemos sobre su proyecto. En este caso mi repositorio es público, cualquiera puede acceder a él y crearse un repositorio a partir del mismo. El único que puede modificar este repositorio sin crearse una réplica (un fork) soy yo.

3. Una vez has creado un fork de tu repositorio, ábrelo con VSCode en local. 

4. Implementa el buscaminas. No olvides ir haciendo "commits" y "pushs" según vayas avanzando en el desarrollo. Así podrás llevar un seguimiento.



Licencia
--------

La licencia de este repositorio y todo su contenido es [GNU General Public License v.3.0](https://es.wikipedia.org/wiki/Licencia_p%C3%BAblica_general_de_GNU) 
